const ClockInOutPage = () => {
  return <div>ClockInOutPage</div>;
};

export default ClockInOutPage;
