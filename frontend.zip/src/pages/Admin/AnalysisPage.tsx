const AnalysisPage = () => {
  return <div>AnalysisPage</div>;
};

export default AnalysisPage;
