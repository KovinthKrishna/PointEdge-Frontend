const ClockOutPage = () => {
  return <div>ClockOutPage</div>;
};

export default ClockOutPage;
