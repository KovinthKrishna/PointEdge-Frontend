const ClockInPage = () => {
  return <div>ClockInPage</div>;
};

export default ClockInPage;
