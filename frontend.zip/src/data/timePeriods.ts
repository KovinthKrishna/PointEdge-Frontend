const timePeriods = [
  { id: "TODAY", name: "Today" },
  { id: "YESTERDAY", name: "Yesterday" },
  { id: "THIS_WEEK", name: "This week" },
  { id: "THIS_MONTH", name: "This month" },
  { id: "THIS_YEAR", name: "This year" },
];

export default timePeriods;
