export default interface Admin {
  id: number;
  name: string;
  password: string;
}