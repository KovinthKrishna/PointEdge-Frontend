export enum RefundStep {
    ITEM_SELECTION,
    REFUND_METHOD_SELECTION,
    REFUND_RESULT,
  }
  